# Kodi Addon for Zee 5 -- www.zee5.com

The latest installable .zip can be downloaded from [here](https://github.com/mani-coder/plugin.video.youngkbell.zee5/blob/master/plugin.video.youngkbell.zee5.zip). If you are using Github Browser add-on you can
search for this user and install the add-on and also can enable the update service for auto-updates. 

**Warning**: The "add-on" is only compatible with Kodi 17.0 (Krypton) and above.

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
